from google.appengine.ext import webapp
import urllib,json

class MainHandler(webapp.RequestHandler):
    def get(self):
        post = {
                'client_id' : 'Ololo',
                'client_secret' : 'W1NgVOOmWjBGK8cksmXeXefLzKITRMqknEbGnZ5LpVA=',
                'scope' : 'http://api.microsofttranslator.com',
                'grant_type' : 'client_credentials'
              }

        u = urllib.urlopen(
            'https://datamarket.accesscontrol.windows.net/v2/OAuth2-13',
            data= urllib.urlencode(post))
        d = json.loads(u.read())
        token = d.get('access_token','null')

        self.response.headers['Content-Type'] = 'application/x-javascript'
        self.response.out.write('m$_translator_token = "%s"'%token)

app = webapp.WSGIApplication([('/', MainHandler)],
                             debug=True)

