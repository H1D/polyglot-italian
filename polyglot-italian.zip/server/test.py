import urllib,simplejson

post = {
			'client_id' : 'Ololo',
          	'client_secret' : 'W1NgVOOmWjBGK8cksmXeXefLzKITRMqknEbGnZ5LpVA=',
          	'scope' : 'http://api.microsofttranslator.com',
          	'grant_type' : 'client_credentials'
          }

u = urllib.urlopen('https://datamarket.accesscontrol.windows.net/v2/OAuth2-13',data= urllib.urlencode(post))

d = simplejson.loads(u.read())
token = d['access_token']